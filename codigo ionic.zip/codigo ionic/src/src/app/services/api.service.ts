import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

let correolog: string = '';
let validador: boolean = false;

export let correoLogueado = (arg:string)=>{
  correolog = arg
}

export let validado = (arg:boolean)=>{
  validador = arg
}

@Injectable({
  providedIn: 'root'
})
export class ApiService {


  rutaBase: string = 'https://fer-sepulveda.cl/API_PRUEBA2/api-service.php'
  apiTest: string = 'https://rickandmortyapi.com/api/character/'

  constructor(private http: HttpClient, private router: Router) { }

  numAleatorio(a,b){
    return Math.round(Math.random() * (b - a) + parseInt(a, 10));
  }
  aleatorio: number = this.numAleatorio(1,826);

  getPersonajes(){
    let that = this;
    let url = `${that.apiTest}${that.aleatorio}`
    that.limpiar();
    return new Promise(resolve => {
      resolve(that.http.get(url).toPromise())
    })
  }

  limpiar() {
    this.aleatorio=this.numAleatorio(1,826);
  }
  canActivate(){
    if(!validador){
      this.router.navigate(['login']);
      return false;
    } else  {
      return true;
    }
    
  }

  usuarioLogin(correo, contrasena) {
    let that = this;
    return new Promise(resolve => {
      resolve(that.http.post(that.rutaBase, {
        nombreFuncion: 'UsuarioLogin',
        parametros:  [correo, contrasena],
      }).toPromise())
    })
  }

  usuarioObtenerNombre() {
    let that = this;
    let url = `${that.rutaBase}?nombreFuncion=UsuarioObtenerNombre&correo=${correolog}`
    return new Promise(resolve => {
      resolve(that.http.get(url).toPromise())
    })
  }

  usuarioAlmacenar(correo, contrasena, nombre, apellido) {
    let that = this;
    return new Promise(resolve => {
      resolve(that.http.post(that.rutaBase, {
        nombreFuncion: 'UsuarioAlmacenar',
        parametros:  [correo, contrasena, nombre, apellido]
      }).toPromise())
    })
  }


  modificarContrasena(correo, contrasenaNueva, contrasenaActual){
    let that = this;

    return new Promise(resolve => {
      resolve(that.http.patch(that.rutaBase, {
        nombreFuncion: 'UsuarioModificarContrasena',
        parametros: [correo, contrasenaNueva, contrasenaActual]
      }).toPromise())
    })
  }

  asistenciaAlmacenar(correo, id_clase) {
    let that = this;

    return new Promise(resolve => {
      resolve(that.http.post(that.rutaBase, {
        nombreFuncion: 'AsistenciaAlmacenar',
        parametros: [correo, id_clase]
      }).toPromise())
    })
  }

  eliminarAsistencia() {
    let that = this;
    let url = `${that.rutaBase}?nombreFuncion=EliminarAsistencia&correo=${correolog}`
    return new Promise(resolve => {
      resolve(that.http.get(url).toPromise())
    })
  }
}
