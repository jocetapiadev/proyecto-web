import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite/ngx';
import { AlertController } from '@ionic/angular';




@Injectable({
  providedIn: 'root'
})
export class DbService {

  validador: boolean = false;
  logueado: boolean = false;
  //mdl_pass: string = 'admin';
  

  
  constructor(private router: Router, private alertController: AlertController, private sqlite: SQLite) { 
    this.sqlite.create({
      name: 'datos.db',
      location: 'default'
    }).then((db: SQLiteObject) => {
      db.executeSql('CREATE TABLE IF NOT EXISTS USUARIO(MAIL VARCHAR(35), CONTRASENA VARCHAR(30))', []).then(() => {
        console.log('PYD: TABLA CREADA OK');
      }).catch(e => {
        console.log('PYD: TABLA NO OK');
      })
    }).catch(e => {
      console.log('PYD: BASE DE DATOS NO OK')
    })

    this.sqlite.create({
      name: 'datos.db',
      location: 'default'
    }).then((db: SQLiteObject) => {
      db.executeSql('CREATE TABLE IF NOT EXISTS ASISTENCIA(MAIL VARCHAR(35), TEXTO VARCHAR(30), CLASE VARCHAR(100), FECHAQR VARCHAR(30))', []).then(() => {
        console.log('PYD: TABLA ASISTENCIA CREADA OK');
      }).catch(e => {
        console.log('PYD: TABLA ASISTENCIA NO OK');
      })
    }).catch(e => {
      console.log('PYD: BASE DE DATOS NO OK')
    })
  }

//INICIO BASE PARA USUARIO
  almacenarUsuario(correo, contrasena) {
    this.sqlite.create({
      name: 'datos.db',
      location: 'default'
    }).then((db: SQLiteObject) => {
      db.executeSql('INSERT INTO USUARIO VALUES(?, ?)', [correo, contrasena]).then(() => {
        console.log('PYD: USUARIO ALMACENADO OK');
      }).catch(e => {
        console.log('PYD: USUARIO NO ALMACENADO');
      })
    }).catch(e => {
      console.log('PYD: BASE DE DATOS NO OK')
    })
  }

  borrarBase() {
    this.sqlite.create({
      name: 'datos.db',
      location: 'default'
    }).then((db: SQLiteObject) => {
      db.executeSql('DROP TABLE USUARIO', []).then(() => {
        console.log('PYD: TABLA ELIMINADA');
      }).catch(e => {
        console.log('PYD: TABLA NO ELIMINADA');
      })
    }).catch(e => {
      console.log('PYD: BASE DE DATOS NO OK')
    })
  }



crearBase(){

  this.sqlite.create({
    name: 'datos.db',
    location: 'default'
  }).then((db: SQLiteObject) => {
    db.executeSql('CREATE TABLE IF NOT EXISTS USUARIO(MAIL VARCHAR(35), CONTRASENA VARCHAR(30))', []).then(() => {
      console.log('PYD: TABLA CREADA OK');
    }).catch(e => {
      console.log('PYD: TABLA NO OK');
    })
  }).catch(e => {
    console.log('PYD: BASE DE DATOS NO OK')
  })
}

getCorreo() {
  return this.sqlite.create({
    name: 'datos.db',
    location: 'default'
  }).then((db: SQLiteObject) => {
    return db.executeSql('SELECT MAIL FROM USUARIO', []).then((data) => {

        return data.rows.item(0).MAIL; 
      
    })
  })
}


// FIN BASE PARA USUARIO

// INICIO BASE PARA ASISTENCIA
almacenarAsistencia(correo, texto, clase, fechaqr) {
  this.sqlite.create({
    name: 'datos.db',
    location: 'default'
  }).then((db: SQLiteObject) => {
    db.executeSql('INSERT INTO ASISTENCIA VALUES(?, ?, ?, ?)', [correo, texto, clase, fechaqr]).then(() => {
      console.log('PYD: ASISTENCIA ALMACENADA OK');
    }).catch(e => {
      console.log('PYD: ASISTENCIA NO ALMACENADA');
    })
  }).catch(e => {
    console.log('PYD: BASE DE DATOS NO OK')
  })
}

getAsistencia(correo) {
  return this.sqlite.create({
    name: 'datos.db',
    location: 'default'
  }).then((db: SQLiteObject) => {
    return db.executeSql('SELECT MAIL, TEXTO, CLASE, FECHAQR  FROM ASISTENCIA WHERE MAIL = (?)', [correo]).then((data) => {
      let arrayAsistencia = [];
      if (data.rows.length > 0) {
        for (var i = 0; i < data.rows.length; i++) {
          arrayAsistencia.push({
            mail: data.rows.item(i).MAIL,
            texto: data.rows.item(i).TEXTO,
            clase: data.rows.item(i).CLASE,
            fechaqr: data.rows.item(i).FECHAQR
          });
        }
      }
      return(arrayAsistencia);
    }, (error) => {
      return(error)
    })

  })
}

borrarBaseAsistencia() {
  this.sqlite.create({
    name: 'datos.db',
    location: 'default'
  }).then((db: SQLiteObject) => {
    db.executeSql('DROP TABLE ASISTENCIA', []).then(() => {
      this.crearBaseAsistencia();
      console.log('PYD: TABLA ASISTENCIA ELIMINADA');
    }).catch(e => {
      console.log('PYD: TABLA ASISTENCIA NO ELIMINADA');
    })
  }).catch(e => {
    console.log('PYD: BASE DE DATOS NO OK')
  })
}

crearBaseAsistencia(){

  this.sqlite.create({
    name: 'datos.db',
    location: 'default'
  }).then((db: SQLiteObject) => {
    db.executeSql('CREATE TABLE IF NOT EXISTS ASISTENCIA(MAIL VARCHAR(35), TEXTO VARCHAR(30), CLASE VARCHAR(100), FECHAQR VARCHAR(30))', []).then(() => {
      console.log('PYD: TABLA CREADA OK');
    }).catch(e => {
      console.log('PYD: TABLA NO OK');
    })
  }).catch(e => {
    console.log('PYD: BASE DE DATOS NO OK')
  })
}

// FIN BASE PARA ASISTENCIA

   // getCorreo() {
  //   return this.sqlite.create({
  //     name: 'base.db',
  //     location: 'default'
  //   }).then((db: SQLiteObject) => {
  //     return db.executeSql('SELECT MAIL FROM USUARIO', []).then((data) => {
  //       if(data.rows.item(0) === 1) {
  //         return data.rows.item(0).MAIL; //FALSE: CORREO NO EXISTE
  //     })
  //   }



  async mensaje(msg) {
    const alert = await this.alertController.create({
      header: 'Info',
      //subHeader: 'Important message',
      message: msg,
      buttons: ['OK']
    });

    await alert.present();
  }

}
