import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';

@Component({
  selector: 'app-barrita',
  templateUrl: './barrita.component.html',
  styleUrls: ['./barrita.component.scss'],
})
export class BarritaComponent implements OnInit {

  mdl_nombre: string = '';
  mdl_apellido: string = '';

  mdl_personaje: string = '';
  mdl_imagen: string = '';
  mdl_id: number;
  mdl_estado: string = '';

  @Input() titulo: string;
  colorHomero: string = '';

  constructor(private router: Router, private api: ApiService) {

    let that = this;

    that.api.usuarioObtenerNombre().then((data:any) => {
      console.log(data);
      that.mdl_nombre = data.result[0].NOMBRE; 
      that.mdl_apellido = data.result[0].APELLIDO;
    })  

    that.api.getPersonajes().then((data2:any) => {
      console.log(data2);
      that.mdl_personaje = data2.name;
      that.mdl_imagen = data2.image;
      that.mdl_id = data2.id;
      that.mdl_estado = data2.status;
    })
  }

  ngOnInit() {}

  Cervecita(){
    if(this.colorHomero == '') {
      this.colorHomero = 'warning';
    }else{
      this.colorHomero = ''
    }

    //this.colorCorazon = this.colorCorazon == '' ? 'danger' : ''; 
    //(la linea de arriba es un internario recomendado para dos parecido al if , else)
  }




}
