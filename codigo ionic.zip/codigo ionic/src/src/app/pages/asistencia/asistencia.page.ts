import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SQLite } from '@ionic-native/sqlite/ngx';
import { ApiService } from 'src/app/services/api.service';
import { DbService } from 'src/app/services/db.service';
import { NavController, Platform } from '@ionic/angular';
import { AlertController,  ToastController } from '@ionic/angular';

import { BarcodeScanner } from '@capacitor-community/barcode-scanner';


@Component({
  selector: 'app-asistencia',
  templateUrl: './asistencia.page.html',
  styleUrls: ['./asistencia.page.scss'],
})
export class AsistenciaPage implements OnInit {

  fechaHoy = new Date().toLocaleDateString("ES",{weekday:"long", year:"numeric", month:"short", day:"numeric"});
  texto: string = '';
  mdl_correo: string = '';
  id_clase: string = '';
  clase: string = '';
  fechaQR: string = '';
  asistencia: string = '';
  private ListAsistencia: any;

  private list_user: any;

  constructor(private router: Router, private api: ApiService, private db: DbService, private sqlite: SQLite, private platform: Platform, private alertController: AlertController,private toastController: ToastController, public navCtrl: NavController) {
    //this.platform.backButton.subscribeWithPriority(10, () => {
    //  console.log('PYD: BOTÓN BACK')
    //});
    try{
      let that = this;
        that.db.getCorreo().then((value) => {
          const str: string = value;
          console.log('PYD: '+str)
          if(str == ''){
            console.log('PYD: Sin datos registrados')
          }else if(str != '')
            console.log('PYD: Con datos registrados.');
            that.mdl_correo = str;
            console.log('PYD: '+str);
          
        })
    }catch{
      console.log('PYD: Sin datos registrados')
    }
  }

  ngOnInit() {
  }

  async leerQR () {
    this.vacio();
    document.querySelector('body').classList.add('scanner-active');
    
    await BarcodeScanner.checkPermission({ force: true });

    BarcodeScanner.hideBackground();
    const result = await BarcodeScanner.startScan(); 
  
    if (result.hasContent) {
      this.texto = (result.content); 
      var arreglo = this.texto.split('|');
      this.id_clase = arreglo[0];
      this.clase = arreglo[1];
      this.fechaQR = arreglo[0].substring(32,40);
      this.registrarAsistencia();
      this.router.navigate(['asistencia']);
    }
    document.querySelector('body').classList.remove('scanner-active');
  };


  cancelarQR() {
    BarcodeScanner.showBackground();
    BarcodeScanner.stopScan();
  }

  async borrarAsistencia() {
    let that = this;
    await that.api.eliminarAsistencia();
    await that.db.borrarBaseAsistencia();
    that.mostrarMensajeError('Asistencia ELIMINADA.');
    that.registro();
  }

  registro() {
    this.db.getAsistencia(this.mdl_correo).then((data: any) => {
      console.log('PYD: '+data)
      this.ListAsistencia = data;
    }, (error) => {
      console.log('PYD: '+error)
    })
  }
  // registro() {
  //   let that = this;
  //     that.db.getAsistencia(this.mdl_correo).then((value) => {
  //       const str: string = value;
  //       console.log('PYD: '+str)
  //       if(str == ''){
  //         console.log('PYD: Sin datos registrados')
  //       }else if(str != '')
  //         console.log('PYD: Con datos registrados.');
  //         that.asistencia = str;
  //         console.log('PYD: '+str);
        
  //     })
  // }

  async registrarAsistencia() {
    let that = this;
    const data:any = await that.api.asistenciaAlmacenar(that.mdl_correo,that.id_clase);
    
    if(data.result[0].RESPUESTA == 'OK'){
      this.db.almacenarAsistencia(this.mdl_correo, this.texto, this.clase, this.fechaQR);
      this.mostrarMensajeOk('Asistencia registrada con éxito.')
    }else if(data.result[0].RESPUESTA == 'ERR03'){
      this.mostrarMensaje('Asistencia ya registrada.')
    }
  }


  vacio(){
    this.router.navigate(['vacio'])
  }

  async mensaje(msg) {
    const alert = await this.alertController.create({
      header: 'Info',
      message: msg,
      buttons: ['OK']
    });

    await alert.present();
  }

  async mostrarMensajeError(mensaje) {
    const toast = await this.toastController.create({
      message: mensaje,
      duration: 3000,
      position: 'bottom',
      color: 'danger'
    });

    await toast.present();
  }

  async mostrarMensajeOk(mensaje) {
    const toast = await this.toastController.create({
      message: mensaje,
      duration: 3000,
      position: 'bottom',
      color: 'success'
    });

    await toast.present();
  }

  async mostrarMensaje(mensaje) {
    const toast = await this.toastController.create({
      message: mensaje,
      duration: 3000,
      position: 'bottom',
      color: 'warning'
    });

    await toast.present();
  }



}
