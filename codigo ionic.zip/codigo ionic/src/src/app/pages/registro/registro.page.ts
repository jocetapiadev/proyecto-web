import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { ApiService } from 'src/app/services/api.service';


@Component({
  selector: 'app-registro',
  templateUrl: './registro.page.html',
  styleUrls: ['./registro.page.scss'],
})
export class RegistroPage implements OnInit {

  mdl_correo: string = '';
  mdl_contrasena:string = '';
  mdl_nombre: string = '';
  mdl_apellido:string = '';

  constructor(private router: Router, private alertController: AlertController, private api: ApiService) { }

  ngOnInit() {
  }

  async mensaje(msg) {
    const alert = await this.alertController.create({
      header: 'Info',
      //subHeader: 'Important message',
      message: msg,
      buttons: ['OK']
    });

    await alert.present();
  }

  async registrar(){
    let that = this;
    let emailRegex = /^[-\w.%+]{1,64}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/i;

    if(this.mdl_correo==''){
      this.mensaje('Dejo el correo sin completar.')
    }else if(this.mdl_contrasena==''){
      this.mensaje('Dejo la contraseña sin completar.')
    }else if(!emailRegex.test(this.mdl_correo)){
      this.mensaje('Ingrese un correo válido')
    }else{
      const data:any = await this.api.usuarioAlmacenar(this.mdl_correo,this.mdl_contrasena,this.mdl_nombre,this.mdl_apellido)
      console.log(data)
      if(data.result[0].RESPUESTA == 'OK'){
        this.mensaje('Usuario registrado con éxito.')
        this.router.navigate(['login'])
      }else if(data.result[0].RESPUESTA == 'ERR01'){
        this.mensaje('Usuario ya registrado.')
      }
    }
  }

  salir(){
    this.router.navigate(['login']);
  }

}
