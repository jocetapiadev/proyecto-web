import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController, NavParams } from '@ionic/angular';
import { BarcodeScanner } from '@capacitor-community/barcode-scanner';

@Component({
  selector: 'app-vacio',
  templateUrl: './vacio.page.html',
  styleUrls: ['./vacio.page.scss'],
})
export class VacioPage implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  cancelarQR() {
    BarcodeScanner.showBackground();
    BarcodeScanner.stopScan();
    this.router.navigate(['asistencia']);
  }


}
