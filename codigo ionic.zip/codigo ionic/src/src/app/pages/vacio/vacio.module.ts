import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { VacioPageRoutingModule } from './vacio-routing.module';

import { VacioPage } from './vacio.page';
import { BarritaComponent } from 'src/app/components/barrita/barrita.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    VacioPageRoutingModule
  ],
  declarations: [VacioPage, BarritaComponent]
})
export class VacioPageModule {}
