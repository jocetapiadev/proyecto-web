import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite/ngx';
import { ApiService } from 'src/app/services/api.service';
import { DbService } from 'src/app/services/db.service';
import { Camera, CameraResultType } from '@capacitor/camera';

@Component({
  selector: 'app-principal',
  templateUrl: './principal.page.html',
  styleUrls: ['./principal.page.scss'],
})
export class PrincipalPage implements OnInit {

  mdl_nombre: string = '';
  mdl_apellido: string = '';

  mdl_personaje: string = '';
  mdl_imagen: string = '';
  mdl_id: number;
  mdl_estado: string = '';

  rutaFoto: string = '';
  

  constructor(private router: Router, private api: ApiService, private db: DbService, private sqlite: SQLite) { 

    let that = this;

    that.api.usuarioObtenerNombre().then((data:any) => {
      console.log(data);
      that.mdl_nombre = data.result[0].NOMBRE; 
      that.mdl_apellido = data.result[0].APELLIDO;
    })  

    that.api.getPersonajes().then((data2:any) => {
      console.log(data2);
      that.mdl_personaje = data2.name;
      that.mdl_imagen = data2.image;
      that.mdl_id = data2.id;
      that.mdl_estado = data2.status;
    })
  }

  ngOnInit() {
  }

  async tomarFoto() {
    const image = await Camera.getPhoto({
      quality: 90,
      allowEditing: true,
      resultType: CameraResultType.Uri
    });
    this.rutaFoto = image.webPath;
  };

  salir(){
    this.db.borrarBase();
    this.router.navigate(['login']);
  }

  modificar(){
    this.router.navigate(['cambiar-contrasena'])
  }

  asistencia(){
    this.router.navigate(['asistencia'])
  }

}
