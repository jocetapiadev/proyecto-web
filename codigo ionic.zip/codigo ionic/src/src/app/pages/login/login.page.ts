import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { ApiService, correoLogueado, validado } from 'src/app/services/api.service';
import { DbService } from 'src/app/services/db.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  mdl_correo: string = '';
  mdl_contrasena: string = '';

  constructor(private router: Router, private api: ApiService, private alertController: AlertController, private db: DbService) { 
  try{
    let that = this;
      that.db.getCorreo().then((value) => {
        const str: string = value;
        console.log('PYD: '+str)
        if(str == ''){
          console.log('PYD: Sin datos registrados')
          that.mdl_correo = '';
          that.mdl_contrasena = '';
          validado(false);

        }else if(str != '')
          console.log('PYD: Con datos registrados.')
          validado(true);
          correoLogueado(str)
          this.router.navigate(['principal'])
          console.log('PYD: '+str)
        
      })
  }catch{
    console.log('PYD: Sin datos registrados')
  }
}
  ngOnInit() {
  }

  async login() {
    let that = this;
    this.db.crearBase();
    const valido:any = await that.api.usuarioLogin(that.mdl_correo,that.mdl_contrasena);
    
    if(valido.result == 'LOGIN OK' ){
      that.almacenarUsuario(that.mdl_correo, that.mdl_contrasena);
      console.log('PYD: '+ that.mdl_correo + that.mdl_contrasena);
      console.log('PYD: LOGUEADO');

      validado(true);
      correoLogueado(that.mdl_correo);
      
      that.router.navigate(['principal']);        
      that.mdl_correo = "";
      that.mdl_contrasena = "";
    }else if(valido.result == 'LOGIN NOK' ){
      that.mensaje('Hay un problema con el usuario o contraseña');
      console.log('FYD: PROBLEMAS DE LOGIN');
      validado(false);

    }
  }

  almacenarUsuario(correo, contrasena) {
    this.db.almacenarUsuario(correo, contrasena);
  }

  registro(){
    this.router.navigate(['registro'])
  }


  async mensaje(msg) {
    const alert = await this.alertController.create({
      header: 'Informacion',
      message: msg,
      buttons: ['OK']
    });

    await alert.present();
  }




}
