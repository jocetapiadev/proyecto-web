import { Component, OnInit } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { AlertController, LoadingController, ToastController } from '@ionic/angular';
import { ApiService } from 'src/app/services/api.service';
import { DbService } from 'src/app/services/db.service';


@Component({
  selector: 'app-cambiar-contrasena',
  templateUrl: './cambiar-contrasena.page.html',
  styleUrls: ['./cambiar-contrasena.page.scss'],
})
export class CambiarContrasenaPage implements OnInit {

  mdl_correo:String = ''
  mdl_newcontra: String = ''
  mdl_oldcontra:String = ''

  constructor(private alertController: AlertController,private router:Router,private loadingCtrl:LoadingController,private toastController: ToastController,private api:ApiService, private db: DbService) { 
  try{
    let that = this;
      that.db.getCorreo().then((value) => {
        const str: string = value;
        console.log('PYD: '+str)
        if(str == ''){
          console.log('PYD: Sin datos registrados')
        }else if(str != '')
          console.log('PYD: Con datos registrados.');
          that.mdl_correo = str;
          console.log('PYD: '+str);
        
      })
  }catch{
    console.log('PYD: Sin datos registrados')
  }
}

  ngOnInit() {
  }



  modificar(){
    let that = this;
    this.loadingCtrl.create({
      message: 'Cambiando Contraseña...',
      spinner: 'bubbles'
    }).then(async res => {
      res.present();

      let data = await that.api.modificarContrasena(this.mdl_correo, this.mdl_newcontra, this.mdl_oldcontra);
      console.log('MODIFICAR:',data);
      
      if(data['result'][0].RESPUESTA == 'OK') {
        that.mostrarMensajeOk('Contraseña Modificada Correctamente.');
        that.limpiar();
        that.router.navigate(['principal']);
      }else if (data['result'][0].RESPUESTA == 'ERR02') {
        that.mostrarMensaje('Contraseña actual erronea');
      }else {
        that.mostrarMensajeError('Error al Cambiar la contraseña');
      }
      res.dismiss();
    });

  }

  async mostrarMensajeError(mensaje) {
    const toast = await this.toastController.create({
      message: mensaje,
      duration: 3000,
      position: 'bottom',
      color: 'danger'
    });

    await toast.present();
  }

  async mostrarMensajeOk(mensaje) {
    const toast = await this.toastController.create({
      message: mensaje,
      duration: 3000,
      position: 'bottom',
      color: 'success'
    });

    await toast.present();
  }

  async mostrarMensaje(mensaje) {
    const toast = await this.toastController.create({
      message: mensaje,
      duration: 3000,
      position: 'bottom',
      color: 'warning'
    });

    await toast.present();
  }



  limpiar() {
    this.mdl_correo='';
    this.mdl_newcontra='';
    this.mdl_oldcontra='';
  }



}
