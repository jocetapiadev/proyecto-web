//Ejecutando funciones
document.getElementById("btn__iniciar-sesion").addEventListener("click", iniciarSesion);
document.getElementById("btn__registrarse").addEventListener("click", register);
window.addEventListener("resize", anchoPage);

//Declarando variables
var formulario_login = document.querySelector(".formulario__login");
var formulario_register = document.querySelector(".formulario__register");
var contenedor_login_register = document.querySelector(".contenedor__login-register");
var caja_trasera_login = document.querySelector(".caja__trasera-login");
var caja_trasera_register = document.querySelector(".caja__trasera-register");


const apiUrl = 'https://fer-sepulveda.cl/API_PRUEBA2/api-service.php';
const nombreU = 'https://fer-sepulveda.cl/API_PRUEBA2/api-service.php?nombreFuncion=UsuarioObtenerNombre&correo=';
var mail = '';
var nombreApellido = '';
//FUNCIONES
    
function login(){
    let correo = document.getElementById("mail").value;
    let contrasena = document.getElementById("pass").value;
    const datos = {nombreFuncion: 'UsuarioLogin', parametros:  [correo, contrasena]};
    mail = correo;
    const request = {
        method: 'POST',
        Headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(datos)
    };
    fetch(apiUrl, request)
        .then(response => response.json()) // Transformamos la respuesta a formato JSON
        .then(data => {
            if(data.result == 'LOGIN OK' ){
                location.href ='principal.html';
            }else if(data.result == 'LOGIN NOK' ){
                alert('Hay un problema con el usuario o contraseña');
            }
    });
};

function registrar(){
    let correo = document.getElementById("mailu").value;
    let contrasena = document.getElementById("contrasenau").value;
    let nombre = document.getElementById("nombre").value;
    let apellido = document.getElementById("apellido").value;
    const datos = {nombreFuncion: 'UsuarioAlmacenar', parametros:  [correo, contrasena, nombre, apellido]};
    const request = {
        method: 'POST',
        Headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(datos)
    };
    fetch(apiUrl, request)
        .then(response => response.json()) // Transformamos la respuesta a formato JSON
        .then(data => {
            if(data.result[0].RESPUESTA == 'OK'){
                alert('Usuario registrado con éxito.');
                location.href = 'login.html';
            }else if (data.result[0].RESPUESTA == 'ERR01'){
                alert('Usuario ya registrado.');
            }
        });
};

window.addEventListener("load", function(){
    fetch(nombreU+mail)
    .then(response => response.json())
    .then(json => console.log(json))
    .catch(err => console.log('Nombre fallido, err'));
    
    console.log("Documento cargado");
        
    
});
    

    
function anchoPage(){

    if (window.innerWidth > 850){
        caja_trasera_register.style.display = "block";
        caja_trasera_login.style.display = "block";
    }else{
        caja_trasera_register.style.display = "block";
        caja_trasera_register.style.opacity = "1";
        caja_trasera_login.style.display = "none";
        formulario_login.style.display = "block";
        contenedor_login_register.style.left = "0px";
        formulario_register.style.display = "none";   
    }
}

anchoPage();


    function iniciarSesion(){
        if (window.innerWidth > 850){
            formulario_login.style.display = "block";
            contenedor_login_register.style.left = "10px";
            formulario_register.style.display = "none";
            caja_trasera_register.style.opacity = "1";
            caja_trasera_login.style.opacity = "0";
        }else{
            formulario_login.style.display = "block";
            contenedor_login_register.style.left = "0px";
            formulario_register.style.display = "none";
            caja_trasera_register.style.display = "block";
            caja_trasera_login.style.display = "none";
        }
    }

    function register(){
        if (window.innerWidth > 850){
            formulario_register.style.display = "block";
            contenedor_login_register.style.left = "410px";
            formulario_login.style.display = "none";
            caja_trasera_register.style.opacity = "0";
            caja_trasera_login.style.opacity = "1";
        }else{
            formulario_register.style.display = "block";
            contenedor_login_register.style.left = "0px";
            formulario_login.style.display = "none";
            caja_trasera_register.style.display = "none";
            caja_trasera_login.style.display = "block";
            caja_trasera_login.style.opacity = "1";
        }
}


function descargas(){

    if (navigator.userAgent.match(/Android/i) || navigator.userAgent.match(/webOS/i) || navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/iPod/i) || navigator.userAgent.match(/BlackBerry/i) || navigator.userAgent.match(/Windows Phone/i) || window.innerWidth <= 780) {
        alert("Toma Pop-Up, por entrar con un dispositivo móvil");
        document.body.innerHTML += "<button id='b1' href='/assets/file/RegistrAPP.apk'>Descargar</button>";
    } else {
        console.log("No estás usando un móvil");
    }
}
